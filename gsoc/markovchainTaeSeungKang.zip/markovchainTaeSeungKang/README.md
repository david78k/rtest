# markovchain
Easy Handling Discrete Time Markov Chains
